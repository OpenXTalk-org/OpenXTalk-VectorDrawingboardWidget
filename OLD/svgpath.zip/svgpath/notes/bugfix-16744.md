# [16744] Default to non-zero SVG fill winding rule
