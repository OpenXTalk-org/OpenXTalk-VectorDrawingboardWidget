# Implementation

The svgpath widget will now only perform costly scaledWidth and scaledHeight
recalculations when the widget width or height changes.
