---
version: 8.0.0-dp-6
---
# Properties

* The property inspector editor for the **iconPathPreset** property is
  now an instance of the SVG Icon widget itself, which pops up the Icon
  Picker widget when clicked.
