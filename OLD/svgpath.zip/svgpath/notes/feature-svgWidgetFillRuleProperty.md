# Properties

* A new **fillRule** property has been added.  It is an enum that can be set to
  "non-zero" or "even odd", and it is "non-zero" by default.
